#ifndef __FILEIO_H__
#define __FILEIO_H__

char* open_file(const char* input_file);

#endif
